<?php
// place here your code to process the form

?>
<html>
<head>
<title>Modal upload</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="thickbox.js"></script>
<link rel="stylesheet" href="thickbox.css" type="text/css" media="screen" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>
<body>
	<div id="container">
		<h1>Example form...</h1>
		<p>Enter a name, click <strong>Upload</strong> to select/upload a file.</p>
		<form action="form.php" method="post">
			<p>
				<label for="nametag">Name</label>
				<input type="text" name="nametag" size="20" />
			</p>
			<p>
				<label for="myfile">File name</label>
				<input type ="text" id="myfile" name="myfile" readonly="readonly" />
		 		 <a href="upload.php?placeValuesBeforeTB_=savedValues&TB_iframe=true&height=300&width=400&modal=true" class="thickbox">Upload</a>
		 	</p>
		 	<p style="text-align:right;"><input type="submit" name="Submit" value="Send" /></p>
		</form>
	</div>
</body>
</html>
